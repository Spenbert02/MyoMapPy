# MyoMapPy
A python library for diffusion tensor-based tractography of the heart.

# License
MyoMApPy is licensed under the terms of the GNU AGPLv3 license.