def printHelloWorld():
    print("hello world")